//
//  NewCollectionCell.swift
//  MachineTes
//
//  Created by Mac on 10/08/23.
//

import UIKit

class NewnextCollectionCell: UICollectionViewCell {

    @IBOutlet weak var cellview: UIView!
    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var downbtn: UIButton!
   // #colorLiteral(red: 0.2039215686, green: 0.7803921569, blue: 0.3490196078, alpha: 1)
    
    
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
